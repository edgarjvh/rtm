<?php

namespace App\Http\Controllers;

use App\Organization;
use Illuminate\Http\Request;
use Socialite;
use App\User;
use Auth;

class SocialAuthController extends Controller
{
    public function __construct()
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
    }

    public function redirectToProvider($provider)
    {
        return Socialite::driver($provider)
            ->scopes([
                'https://www.googleapis.com/auth/calendar',
                'https://www.googleapis.com/auth/userinfo.profile',
                'https://www.googleapis.com/auth/userinfo.email'
            ])
            ->with(["access_type" => "offline", "prompt" => "consent select_account"])
            ->redirect();
    }

    public function handleProviderCallback($provider)
    {
        try {
            $userSocial = Socialite::driver($provider)->user();

            $user = User::where(['email' => $userSocial->getEmail()])->first();

            if ($user) {
                switch ($provider) {
                    case 'google':
                        User::where(['email' => $userSocial->getEmail()])->update(array(
                            'google_access_token' => $userSocial->token,
                            'google_refresh_token' => $userSocial->refreshToken,
                            'google_expiry_token' => $userSocial->expiresIn,
                            'google_avatar' => $userSocial->getAvatar(),
                            'google_id' => $userSocial->getId()
                        ));
                        break;
                }

                Auth::login($user);
                return redirect('/home');
            } else {
                return view('auth.register', [
                    'name' => $userSocial->getName(),
                    'email' => $userSocial->getEmail()
                ]);
            }
        } catch (\GuzzleHttp\Exception\ClientException $e) {
            dd($e);
        }
    }
}
