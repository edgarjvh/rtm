@extends('layouts.app')

@section('content')
    <div class="container h-100">
        <div class="row h-100 justify-content-center align-items-center p-4">
            <img src="img/logo.png" alt="">
        </div>
    </div>
@endsection


