<?php $__env->startSection('content'); ?>
    <div class="container h-100">
        <div class="row h-100 justify-content-center align-items-center p-4">
            <img src="img/logo.png" alt="">
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyectos\rtm\resources\views/welcome.blade.php ENDPATH**/ ?>