<?php $__env->startSection('content'); ?>
    <div class="banner">
    </div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 mt-3">
                <div class="row">
                    <div class="col">
                        <div class="col">
                            <label for="" style="font-family: Merriweather, Serif; font-size: 24px;color: #C96756;">
                                Register your organization
                            </label>
                            <br>
                            <br>
                            <br>
                            <br>
                            <img src="img/register-img.png" style="width: 250px" alt="">
                        </div>
                    </div>
                    <div class="col">
                        <form method="POST" action="<?php echo e(route('register')); ?>" autocomplete="off">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="name" class="m-0"><?php echo e(__('Name')); ?></label>

                                <?php if(!empty($name)): ?>
                                    <input id="name" type="text"
                                           class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name"
                                           value="<?php echo e($name); ?>" required autocomplete="name" autofocus>
                                <?php else: ?>
                                    <input id="name" type="text"
                                           class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name"
                                           value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                <?php endif; ?>

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>

                            <div class="form-group">
                                <label for="email"
                                       class="m-0"><?php echo e(__('E-Mail Address')); ?></label>

                                <?php if(!empty($email)): ?>
                                    <input id="email" type="email"
                                           class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email"
                                           value="<?php echo e($email); ?>" required autocomplete="email">
                                <?php else: ?>
                                    <input id="email" type="email"
                                           class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email"
                                           value="<?php echo e(old('email')); ?>" required autocomplete="email">
                                <?php endif; ?>

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>

                            <div class="form-group" style="position: relative;">
                                <label for="txt-organization"
                                       class="m-0">Organization</label>

                                <input id="txt-organization" type="text"
                                       class="form-control <?php if ($errors->has('organization')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('organization'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                       name="organization" required
                                       autocomplete="organization">

                                <div id="org-msg"></div>
                                <?php if ($errors->has('organization')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('organization'); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>

                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                <div class="ctl-drop-down">

                                </div>
                            </div>

                            <div class="form-group">
                                <label for="password"
                                       class="mb-0"><?php echo e(__('Password')); ?></label>

                                <input id="password" type="password"
                                       class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password"
                                       required autocomplete="new-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>

                            <div class="form-group">
                                <label for="password-confirm"
                                       class="m-0"><?php echo e(__('Confirm Password')); ?></label>

                                <input id="password-confirm" type="password" class="form-control"
                                       name="password_confirmation" required autocomplete="new-password">

                            </div>

                            <div class="form-group row mb-4">
                                <button type="submit" class="nav-link">
                                    REGISTER
                                </button>
                            </div>

                            <hr>

                            <div class="form-group col mt-1 text-center">
                                <label class="control-label col text-center">Or Login With <span
                                            style="color: #C96756; margin-left: 3px"> Google</span></label>

                                <a href="<?php echo e(url('login/google')); ?>"
                                   class="col">
                                    <img src="img/goo_singup.png" style="width: 24px" alt="">
                                </a>
                            </div>

                            <input type="hidden" name="type" value="owner">
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script>

        $(document).on('keyup', '#txt-organization', delay(function (e) {
            $('#org-msg').html(
                '<i class="fa fa-spin fa-spinner"></i>'
            );

            if (this.value !== '') {
                $.ajax({
                    type: 'post',
                    url: '/checkorg',
                    data: {
                        'orgName': this.value
                    },
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                    success: function (response) {
                        $('#org-msg').html('');
                        let dd = $('.ctl-drop-down');
                        let inputText = $('#txt-organization').val();

                        dd.hide();
                        dd.html('');

                        let items = '';

                        let orgMatch = false;
                        let nameMatches = '';

                        if (response.length > 0) {
                            for (let i = 0; i < response.length; i++) {
                                items += `
                                <div class="dd-item">
                                    <label for="" class="m-0" data-org="` + response[i].name + `">` + response[i].name + `</label>
                                </div>
                            `;

                                if (!orgMatch) {
                                    if (response[i].name.toString().trim().toLowerCase() === inputText.toString().trim().toLowerCase()) {
                                        orgMatch = true;
                                        nameMatches = response[i].name;
                                    }
                                }
                            }

                            if (orgMatch) {
                                dd.html(
                                    `
                                <div class="dd-item border-bottom bg-info">
                                    <label for="" class="m-0" data-org="` + nameMatches + `">Register under <i>` + nameMatches + `</i> organization</label>
                                </div>
                                `
                                    + items
                                );

                                for (let i = 0; i < dd.find('.dd-item').length; i++) {
                                    let item = dd.find('.dd-item').eq(i);

                                    if (item.find('label').text() === nameMatches) {
                                        item.remove();
                                        break;
                                    }
                                }
                            } else {
                                dd.html(
                                    `
                                <div class="dd-item border-bottom bg-success">
                                    <label for="" class="m-0" data-org="` + inputText + `">` + inputText + ` is available</label>
                                </div>
                                `
                                    + items
                                );
                            }
                            dd.show();
                        } else {
                            dd.html(
                                `
                                <div class="dd-item bg-success">
                                    <label for="" class="m-0" data-org="` + inputText + `">` + inputText + ` is available</label>
                                </div>
                                `
                            );
                            dd.show();
                        }
                    },
                    error: function (a, b, c) {
                        console.log('this ios an ajax error');
                    }
                });
            } else {
                $('#org-msg').html('');
                $('.ctl-drop-down').hide();
            }

        }, 500));

        $(document).on('click', '.ctl-drop-down .dd-item label', function () {
            let lbl = $(this).attr('data-org');
            let formGroup = $(this).closest('.form-group');
            let dd = $(this).closest('.ctl-drop-down');

            formGroup.find('input').val(lbl);
            dd.hide();
            dd.html('');

        });

        $(document).on('click', function () {

        });

        function delay(callback, ms) {
            let timer = 0;
            return function () {
                let context = this, args = arguments;
                clearTimeout(timer);
                timer = setTimeout(function () {
                    callback.apply(context, args);
                }, ms || 0);
            };
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyectos\rtm\resources\views/auth/register.blade.php ENDPATH**/ ?>