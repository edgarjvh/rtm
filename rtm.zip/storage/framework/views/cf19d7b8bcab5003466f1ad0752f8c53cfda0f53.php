<?php $__env->startSection('content'); ?>
    <div class="banner">
    </div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 mt-5">
                <div class="row">
                    <div class="col">
                        <div class="col">
                            <label for="" style="font-family: Merriweather, Serif; font-size: 24px;color: #C96756;">
                                Login
                            </label>
                            <br>
                            <br>
                            <img src="img/login-img.png" alt="">
                        </div>
                    </div>
                    <div class="col">
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="email" class="m-0"><?php echo e(__('E-Mail Address')); ?></label>

                                <input id="email" type="email"
                                       class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email"
                                       value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>

                            <div class="form-group">
                                <label for="password" class="m-0"><?php echo e(__('Password')); ?></label>

                                <input id="password" type="password"
                                       class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password"
                                       required autocomplete="current-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>

                            <div class="form-group row pl-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember"
                                           id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember">
                                        <?php echo e(__('Remember Me')); ?>

                                    </label>
                                </div>
                            </div>

                            <div class="form-group row mb-4">
                                <button type="submit" class="nav-link">
                                    LOGIN
                                </button>

                                <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" style="color: #C96756"
                                       href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>
                            </div>

                            <hr>

                            <div class="form-group col mt-1 text-center">
                                <label class="control-label col text-center">Or Login With <span
                                            style="color: #C96756; margin-left: 3px"> Google</span></label>

                                <a href="<?php echo e(url('login/google')); ?>"
                                   class="col">
                                    <img src="img/goo_singup.png" style="width: 24px" alt="">
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyectos\rtm\resources\views/auth/login.blade.php ENDPATH**/ ?>