<?php

namespace App\Http\Controllers;

use App\Event;
use App\RatingKey;
use DateTime;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Str;
use Microsoft\Graph\Graph;
use Microsoft\Graph\Model;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use League\OAuth2\Client\Provider\Exception\IdentityProviderException;
use League\OAuth2\Client\Provider\GenericProvider;
use Auth;

class OutlookController extends Controller
{
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::user();

            return $next($request);
        });
    }

    public function login()
    {
        if (!$this->user) {
            Redirect::to('login')->send();
        }

        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        // Initialize the OAuth client
        $oauthClient = new GenericProvider([
            'clientId' => env('OAUTH_APP_ID'),
            'clientSecret' => env('OAUTH_APP_PASSWORD'),
            'redirectUri' => env('OAUTH_REDIRECT_URI'),
            'urlAuthorize' => env('OAUTH_AUTHORITY') . env('OAUTH_AUTHORIZE_ENDPOINT'),
            'urlAccessToken' => env('OAUTH_AUTHORITY') . env('OAUTH_TOKEN_ENDPOINT'),
            'urlResourceOwnerDetails' => '',
            'scopes' => env('OAUTH_SCOPES')
        ]);

        $url = $oauthClient->getAuthorizationUrl(); // this can be set based on whatever

        $_SESSION['outlook_oauth_state'] = $oauthClient->getState();

        header("Location: $url");
        exit();
    }

    public function outlookauth()
    {
        if (!$this->user) {
            Redirect::to('login')->send();
        }

        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        // Authorization code should be in the "code" query param
        if (isset($_GET['code'])) {
            // Check that state matches
            if (empty($_GET['state']) || ($_GET['state'] !== $_SESSION['outlook_oauth_state'])) {
                exit('State provided in redirect does not match expected value.');
            }

            // Clear saved state
            unset($_SESSION['outlook_oauth_state']);

            // Initialize the OAuth client
            $oauthClient = new GenericProvider([
                'clientId' => env('OAUTH_APP_ID'),
                'clientSecret' => env('OAUTH_APP_PASSWORD'),
                'redirectUri' => env('OAUTH_REDIRECT_URI'),
                'urlAuthorize' => env('OAUTH_AUTHORITY') . env('OAUTH_AUTHORIZE_ENDPOINT'),
                'urlAccessToken' => env('OAUTH_AUTHORITY') . env('OAUTH_TOKEN_ENDPOINT'),
                'urlResourceOwnerDetails' => '',
                'scopes' => env('OAUTH_SCOPES')
            ]);

            try {
                // Make the token request
                $accessToken = $oauthClient->getAccessToken('authorization_code', [
                    'code' => $_GET['code']
                ]);

                $graph = new Graph();
                $graph->setAccessToken($accessToken->getToken());

                $outlook_user = $graph->createRequest('GET', '/me')
                    ->setReturnType(Model\User::class)
                    ->execute();

                $this->storeTokens(
                    $this->user->email,
                    $outlook_user->getUserPrincipalName(),
                    $accessToken->getToken(),
                    $accessToken->getRefreshToken(),
                    $accessToken->getExpires()
                );

                return redirect('/home');
            } catch (IdentityProviderException $e) {
                exit('ERROR getting tokens: ' . $e->getMessage());
            }
            exit();
        } else {
            Redirect::to('/outlook')->send();
        }
    }

    public function outlookCalendar(){
        if (session_status() !== PHP_SESSION_ACTIVE){
            session_start();
        }

        $users = User::whereNotNull('outlook_access_token')->get();

        if (count($users) > 0){
            foreach ($users as $ouser){
                $now = time() + 300;
                $otoken = $ouser->outlook_access_token;

                if ($ouser->outlook_expiry_token <= $now) {
                    // Token is expired (or very close to it)
                    // so let's refresh

                    // Initialize the OAuth client
                    $oauthClient = new GenericProvider([
                        'clientId' => env('OAUTH_APP_ID'),
                        'clientSecret' => env('OAUTH_APP_PASSWORD'),
                        'redirectUri' => env('OAUTH_REDIRECT_URI'),
                        'urlAuthorize' => env('OAUTH_AUTHORITY') . env('OAUTH_AUTHORIZE_ENDPOINT'),
                        'urlAccessToken' => env('OAUTH_AUTHORITY') . env('OAUTH_TOKEN_ENDPOINT'),
                        'urlResourceOwnerDetails' => '',
                        'scopes' => env('OAUTH_SCOPES')
                    ]);

                    try {
                        $newToken = $oauthClient->getAccessToken('refresh_token', [
                            'refresh_token' => $ouser->outlook_refresh_token
                        ]);

                        // Store the new values
                        $this->storeTokens(
                            $ouser->email,
                            $ouser->outlook_account,
                            $newToken->getToken(),
                            $newToken->getRefreshToken(),
                            $newToken->getExpires()
                        );

                        $otoken = $newToken->getToken();
                    }
                    catch (IdentityProviderException $e) {
                        return '';
                    }
                }

                $graph = new Graph();
                $graph->setAccessToken($otoken);

                $eventsQueryParams = array (
                    // // Only return Subject, Start, and End fields
                    "\$select" => "subject,start,end,attendees,isAllDay, IsCancelled, IsOrganizer, organizer, bodyPreview",
                    // Sort by Start, oldest first
                    "\$orderby" => "Start/DateTime"
                );

                $getEventsUrl = '/me/events?'.http_build_query($eventsQueryParams);
                $events = $graph->createRequest('GET', $getEventsUrl)
                    ->setReturnType(Model\Event::class)
                    ->execute();

                //return $events;
                $now = time();

                foreach ($events as $event){
                    //echo '0';
                    if($event->getIsOrganizer() && !$event->getIsAllDay() && !$event->getIsCancelled()){
                        //echo '1';
                        $organizer = $event->getOrganizer()->getEmailAddress()->getAddress();
                        $dtStart = strtotime($event->getStart()->getDateTime());
                        $dtEnd = strtotime($event->getEnd()->getDateTime());

                        // is meeting over in less than 1 day
                        if ((ceil(($now - $dtEnd) / 60) >= 0) && ((ceil($now - $dtEnd) / 60) < 1440)){
                            //echo '2';
                            // is meeting duration is greater than 20 minutes but less than 1 day
                            if ((ceil(($dtEnd - $dtStart) / 60) > 20) && (ceil(($dtEnd - $dtStart) / 60) < 1440)) {
                                //echo '3';
                                if (count($event->getAttendees()) > 0){
                                    //echo '4';
                                    //return $event->getAttendees();

                                    foreach($event->getAttendees() as $attendee){
                                        if($attendee['emailAddress']['address'] !== $organizer){
                                            $rating_key = Str::random(100);
                                            $eventExist = Event::where('event_id', $event->getId())->first();

                                            // if event is not in database, will be saved
                                            if (!$eventExist) {
                                                $newEvent = new Event();
                                                $newEvent->organizer = $organizer;
                                                $newEvent->start_date = date('Y-m-d H:i:s', $dtStart);
                                                $newEvent->end_date = date('Y-m-d H:i:s', $dtEnd);
                                                $newEvent->attendees = count($event->getAttendees());
                                                $newEvent->event_id = $event->getId();
                                                $newEvent->provider = 'outlook';
                                                $newEvent->title = $event->getSubject();
                                                $newEvent->description = $event->getBodyPreview();
                                                $newEvent->save();
                                            }

                                            $key = new RatingKey();
                                            $key->rating_key = $rating_key;
                                            $key->save();

                                            app()->call('\App\Http\Controllers\MessagesController@sendEmail',
                                                [
                                                    $attendee['emailAddress']['address'],
                                                    $rating_key,
                                                    $event->getId()
                                                ]);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    //echo '<br>';
                }
            }
        }
    }

    public function storeTokens($email, $outlook_account, $access_token, $refresh_token, $expires)
    {
        User::where(['email' => $email])->update(array(
            'outlook_account' => $outlook_account,
            'outlook_access_token' => $access_token,
            'outlook_refresh_token' => $refresh_token,
            'outlook_expiry_token' => $expires
        ));
    }

    public function getAccessToken()
    {
        // Check if tokens exist
        if (empty($this->user->outlook_access_token) ||
            empty($this->user->outlook_refresh_token) ||
            empty($this->user->outlook_expiry_token)){
            return '';
        }

        // Check if token is expired
        //Get current time + 5 minutes (to allow for time differences)
        $now = time() + 300;
        if ($this->user->outlook_expiry_token <= $now) {
            // Token is expired (or very close to it)
            // so let's refresh

            // Initialize the OAuth client
            $oauthClient = new GenericProvider([
                'clientId' => env('OAUTH_APP_ID'),
                'clientSecret' => env('OAUTH_APP_PASSWORD'),
                'redirectUri' => env('OAUTH_REDIRECT_URI'),
                'urlAuthorize' => env('OAUTH_AUTHORITY') . env('OAUTH_AUTHORIZE_ENDPOINT'),
                'urlAccessToken' => env('OAUTH_AUTHORITY') . env('OAUTH_TOKEN_ENDPOINT'),
                'urlResourceOwnerDetails' => '',
                'scopes' => env('OAUTH_SCOPES')
            ]);

            try {
                $newToken = $oauthClient->getAccessToken('refresh_token', [
                    'refresh_token' => $this->user->outlook_refresh_token
                ]);

                // Store the new values
                $this->   storeTokens($newToken->getToken(), $newToken->getRefreshToken(),
                    $newToken->getExpires());

                return $newToken->getToken();
            }
            catch (IdentityProviderException $e) {
                return '';
            }
        }
        else {
            // Token is still valid, just return it
            return $this->user->outlook_access_token;
        }
    }
}
