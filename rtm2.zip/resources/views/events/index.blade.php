@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">My Meetings</div>

                    <div class="card-body">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th scope="col">Provider</th>
                                <th scope="col">Organizer</th>
                                <th scope="col">Title</th>
                                <th scope="col">Start Date</th>
                                <th scope="col">End Date</th>
                                <th scope="col">Rate</th>
                            </tr>
                            </thead>
                            <tbody>
                            @if(count($newEvents) > 0)
                                @foreach($newEvents as $event)
                                    <tr>
                                        <td class="align-middle">{{ ucwords($event->provider) }}</td>
                                        <td class="align-middle">
                                            <b>{{$event->name}}</b>
                                            <br>
                                            <small>{{$event->organizer}}</small>
                                        </td>
                                        <td class="align-middle">{{$event->title}}</td>
                                        <td class="align-middle">{{$event->start_date}}</td>
                                        <td class="align-middle">{{$event->end_date}}</td>
                                        <td class="align-middle">{{$event->rate === null ? 'unrated' : number_format($event->rate,1)}}</td>
                                    </tr>
                                @endforeach
                            @else
                                <tr>
                                    <td colspan="6">No meetings to show</td>
                                </tr>
                            @endif
                            </tbody>
                            <tfoot>
                            <tr>
                                <td colspan="6">{{ $newEvents->links() }}</td>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection