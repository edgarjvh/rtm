@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Thank you</div>

                    <div class="card-body">

                        Your rating has been placed!
                        <br>
                        if you would like to rate your own meetings <a href="/register">click here</a> to sign up.

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection