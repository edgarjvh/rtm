<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Dashboard</div>

                    <div class="card-body d-flex flex-row justify-content-around flex-wrap">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if($userLogged): ?>

                            <?php if($userLogged->google_access_token == null): ?>
                                <a href="/googleauth" class="btn btn-info pt-3 pb-3 mt-2 ml-1 mr-1 flex-grow-1">Authorize your Google Calendar</a>
                            <?php else: ?>
                                <a href="#" class="btn btn-success pt-3 pb-3 mt-2 ml-1 mr-1 flex-grow-1">Google Calendar is authorized</a>
                            <?php endif; ?>

                            <?php if($userLogged->outlook_access_token == null): ?>
                                <a href="/outlookauth" class="btn btn-info pt-3 pb-3 mt-2 ml-1 mr-1 flex-grow-1">Authorize your Outlook Calendar</a>
                            <?php else: ?>
                                <a href="#" class="btn btn-success pt-3 pb-3 mt-2 ml-1 mr-1 flex-grow-1">Outlook Calendar is authorized</a>
                            <?php endif; ?>

                            <?php if($userLogged->apple_access_token == null): ?>
                                <a href="#" class="btn btn-info pt-3 pb-3 mt-2 ml-1 mr-1 flex-grow-1">Authorize your Apple Calendar</a>
                            <?php else: ?>
                                <a href="#" class="btn btn-success pt-3 pb-3 mt-2 ml-1 mr-1 flex-grow-1">Apple Calendar is authorized</a>
                            <?php endif; ?>
                        <?php endif; ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyectos\rtm\resources\views/home.blade.php ENDPATH**/ ?>