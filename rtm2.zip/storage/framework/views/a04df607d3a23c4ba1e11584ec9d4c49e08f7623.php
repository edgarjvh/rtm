<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">My Meetings</div>

                    <div class="card-body">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th scope="col">Provider</th>
                                <th scope="col">Organizer</th>
                                <th scope="col">Title</th>
                                <th scope="col">Start Date</th>
                                <th scope="col">End Date</th>
                                <th scope="col">Rate</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(count($newEvents) > 0): ?>
                                <?php $__currentLoopData = $newEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="align-middle"><?php echo e(ucwords($event->provider)); ?></td>
                                        <td class="align-middle">
                                            <b><?php echo e($event->name); ?></b>
                                            <br>
                                            <small><?php echo e($event->organizer); ?></small>
                                        </td>
                                        <td class="align-middle"><?php echo e($event->title); ?></td>
                                        <td class="align-middle"><?php echo e($event->start_date); ?></td>
                                        <td class="align-middle"><?php echo e($event->end_date); ?></td>
                                        <td class="align-middle"><?php echo e($event->rate === null ? 'unrated' : number_format($event->rate,1)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6">No meetings to show</td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <td colspan="6"><?php echo e($newEvents->links()); ?></td>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyectos\rtm\resources\views/events/index.blade.php ENDPATH**/ ?>